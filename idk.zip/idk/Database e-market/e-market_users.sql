-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: e-market
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `Nickname` varchar(20) NOT NULL,
  `Password` varchar(64) NOT NULL,
  `isFinancialAdvisor` tinyint NOT NULL,
  `email` varchar(45) NOT NULL,
  `balance` double DEFAULT NULL,
  PRIMARY KEY (`Nickname`),
  UNIQUE KEY `Nickname_UNIQUE` (`Nickname`),
  UNIQUE KEY `userId_UNIQUE` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (20,'123','a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3',0,'123',0),(18,'aaaaaaaaaa','0c0beacef8877bbf2416eb00f2b5dc96354e26dd1df5517320459b1236860f8c',0,'aaaa',0),(12,'bocca','14fee5f40d89a9ad2911ebe4d8dec60c7ddac463baa06f6322ccffd0e8b519a9',0,'boccalino',0),(14,'cabbo','c053ed16d6a9526382902ae1f99d5ec746469c726a75c46dff648c139ce5f2e2',0,'ilnostroamoreèmortoemièrimastol\'odio',0),(17,'castrovilli','9daba273a5b9e83d437ab9584e5f4c04f510011a2f173239741d4e5edf82ee40',0,'212',0),(11,'dado','07eb7bdfdab82e5126409f943e59947db1c28cee6e252f3ada9774c0f1e78b89',0,'dadone',0),(15,'Giorgio','7da150491281c73a3b9fb06d36963c598efc2e061c11a6d1593ca9e17f787389',0,'giorgiozucco',1.000000000001088e20),(13,'loft','5d3134c23b4de78f92cbd91c6601760cdc41bc745b52b25ecfbaf226bcfd1f51',0,'loft',0),(5,'open','2348f998744212575d85959674f9607ab26f67708a917157472832386337c904',0,'open',18907.042016997933),(8,'opena','991b821cf2f77f904a198df95b3910de9ad54b4c7e55528b06f8d2726ffa38b5',0,'open',0),(21,'pippo','a2242ead55c94c3deb7cf2340bfef9d5bcaca22dfe66e646745ee4371c633fc8',0,'pippo@gmail.com',0),(19,'ssssssss','1369e24b84c92ea0e0358e423702f9e1d05df47fecfc9e9605e6f7fbe8d98a16',0,'sssssssss',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-03 19:45:48
